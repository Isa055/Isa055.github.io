# Portfolio Webpage Example

A Pen created on CodePen.

Original URL: [https://codepen.io/Isa055/pen/azzaYpZ](https://codepen.io/Isa055/pen/azzaYpZ).

Source: codewithsadee (https://www.youtube.com/watch?v=SoxmIlgf2zM)